# ONEMR_Loader by user95401

load dlls in all ur game directory

Patch Exceptions:
> if contains word in dll root patch
- geode
- minhook
- MinHook

## <co>Converted for Geode</c>
---

<cr>This is traditional mod that uses minhook, gd.h, cocos-haders!

BUT! In general, this mod works, and IN MOST CASES IT is COMPATIBLE.
- Made with curly-eureka</c>
