# libcurldist
made for installing mod loader to a clear game

libcurl.dll is file that game loading:
1. game loading libcurl.dll
2. libcurl.dll loading ONEMR_Loader.dll
